# Ferachem website

A responsive, one-page static website for Ferachem, designed for GitHub Pages.

## Before publishing
1. Open `index.html`.
2. Replace `YOUR_EMAIL@example.com` with your real professional email in both the `href` and visible text.
3. Check all service descriptions and remove anything you do not currently offer.
4. Keep `assets/ferachem-logo.png` in the same relative location.

## Publish with GitHub Pages
1. Upload `index.html` and the `assets` folder to the root of your `ferachem-website` repository.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch `main` and folder `/ (root)`, then save.
5. Wait for GitHub Pages to finish deploying.

This is a static website. The email link opens the visitor's email application; it is not a hosted contact form.
